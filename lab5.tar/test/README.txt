test0 - concatenation of Lab4 tests
test1a - redeclaration of variables, and using undefined variables
test1b - variable declarations in different scopes
test2a - types in simple assignments
test2b - types in expressions
test4a - return types of functions
test4b - correct use of functions
test4c - redefinition of functions
test4d - multiple function bodies
test4e - functions decls with different parameters
test4f - function calls with different parameters
test6a - structs, fields
test6b - correct use of structs
test6c - types of struct fields

